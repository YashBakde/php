<?php
$connect = mysqli_connect("localhost","root","","project1");
if(!$connect)
{
echo "not connected contact";
}
?>
